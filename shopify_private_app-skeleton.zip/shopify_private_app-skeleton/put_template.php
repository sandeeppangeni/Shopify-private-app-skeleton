<?php

	session_start();

	require __DIR__.'/vendor/autoload.php';
	use phpish\shopify;

	require __DIR__.'/conf.php';

	$shopify = shopify\client(SHOPIFY_SHOP, SHOPIFY_APP_API_KEY, SHOPIFY_APP_PASSWORD, true);

	echo '<pre>';

	$themes = $shopify('GET /admin/themes.json');
	foreach ($themes as $value) {
	    if ($value['role'] == 'main') {
	        $theme_ids = $value['id'];

	        // print_r($theme_ids);
	        $theme_name_include = $value['name'];
	        // print_r($theme_name_include);
	    }
	}

	try
	{
		
		$get_template = $shopify("GET /admin/api/2019-07/themes/$theme_ids/assets.json?asset[key]=snippets/product-card-grid.liquid&theme_id=$theme_ids");

		if($get_template){
			echo 'template found';
		}else{
			echo 'not found';
		}

		// $get_template2 = $shopify("GET /admin/api/2019-07/themes/$theme_ids/assets.json?asset[key]=snippets/product-grid-item.liquid&theme_id=$theme_ids");

		// $get_template3 = $shopify("GET /admin/api/2019-07/themes/$theme_ids/assets.json?asset[key]=snippets/product-card.liquid&theme_id=$theme_ids");

		// print_r($get_template);

		// # Making an API request can throw an exception
		// $get_template = $shopify('GET /admin/api/2019-07/themes/76999557204/assets.json?asset[key]=snippets/custom-template.liquid&theme_id=76999557204');
		// print_r($get_template);
// 

		// $put_template = $shopify('PUT /admin/api/2019-07/themes/76999557204/assets.json',array(

		//   "asset" =>  array(
		//     "key" => "snippets/custom-template.liquid",
		//     "value" => "  {% include 'aframe_sswatch' %}"
		//   )
		// ));
		// print_r($put_template);
	}
	catch (shopify\ApiException $e)
	{


		# HTTP status code was >= 400 or response contained the key 'errors'
		echo $e;
		print_R($e->getRequest());
		print_R($e->getResponse());
	}
	catch (shopify\CurlException $e)
	{
		# cURL error
		echo $e;
		print_R($e->getRequest());
		print_R($e->getResponse());
	}

?>
<?php

	define('SHOPIFY_SHOP', 'brookyn-test-store.myshopify.com');
	define('SHOPIFY_APP_API_KEY', '32a3445df2f69e5cc515bd1a7e3156ba');
	define('SHOPIFY_APP_PASSWORD', '62ebcb909b0ad3ed5dedbeb96f0d9a3b');

?>

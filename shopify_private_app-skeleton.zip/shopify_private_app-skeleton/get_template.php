<?php

	session_start();

	require __DIR__.'/vendor/autoload.php';
	use phpish\shopify;

	require __DIR__.'/conf.php';

	$shopify = shopify\client(SHOPIFY_SHOP, SHOPIFY_APP_API_KEY, SHOPIFY_APP_PASSWORD, true);

	echo '<pre>';

	try
	{
		# Making an API request can throw an exception
		// $get_template = $shopify('GET /admin/api/2019-07/themes/76999557204/assets.json?asset[key]=snippets/custom-template.liquid&theme_id=76999557204');
		// $value_data = $get_template['value'];


		// $updatedval = $value_data. "{% include 'aframe_sswatch' %}";
		// $put_template = $shopify('PUT /admin/api/2019-07/themes/76999557204/assets.json',array(
		
		//   "asset" =>  array(
		//     "key" => "snippets/custom-template.liquid",
		//     "value" => "$updatedval",
		//   )

		// ));

		$get_metafield = $shopify("GET /admin/api/2019-07/metafields.json");
		foreach ($get_metafield as $key => $value) {
			if(count($value)){
				if(array_key_exists('namespace', $value)){
					if($value['namespace'] == 'aframe_size_swatch'){
						$file = fopen("test.txt","w");
						$targetfieldid = $value['id'];
						
						 $deltargetfield = $shopify("DELETE /admin/api/2019-07/metafields/$targetfieldid.json");\
						fwrite($file, json_encode($deltargetfield));
						fclose($file);

					}
				}	
			}
		}

		// $get_metafield = $shopify("GET /admin/api/2019-07/metafields.json");

		
		// print_r($get_metafield);



	}
	catch (shopify\ApiException $e)
	{


		# HTTP status code was >= 400 or response contained the key 'errors'
		echo $e;
		print_R($e->getRequest());
		print_R($e->getResponse());
	}
	catch (shopify\CurlException $e)
	{
		# cURL error
		echo $e;
		print_R($e->getRequest());
		print_R($e->getResponse());
	}

?>